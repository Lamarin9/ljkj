package com.example.reshkaa.EsinaAndMyasnikovProduction

import android.graphics.Color
import com.example.reshkaa.EsinaAndMyasnikovProduction.databinding.ActivityMainBinding
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

private lateinit var binding: ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private var pravAnswers = 0
    private var nepravAnswers = 0
    private var obshiyAnswers = 0
    private var color = Color.TRANSPARENT
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.but2ton.isEnabled = false
        binding.button.setOnClickListener {
            it.isEnabled = false
            binding.but2ton.isEnabled = true
            binding.answere.text.clear()
            setColor(Color.TRANSPARENT)
            primerCreate()

        }
        binding.but2ton.setOnClickListener {
            it.isEnabled = false
            binding.button.isEnabled = false
            AnswereProverka()
        }
        }
    private fun obnovaInterface() {
        binding.countRightText.text = "$pravAnswers"
        binding.countErrorText.text = "$nepravAnswers"
        binding.textView3.text = "$obshiyAnswers"
        binding.textView4.text = "%.2f%%".format(pravAnswers.toDouble() / obshiyAnswers * 100)
    }

    private fun setColor(c: Int) {
        color = c
        binding.answere.setBackgroundColor(color)
    }
    private fun primerCreate(){
        var cif1 = (10..99).random()
        var cif2 = (10..99).random()

        while (cif1 % cif2 != 0){
            cif1 = (10..99).random()
            cif2 = (10..99).random()
        }
        binding.textView6.text = "$cif1"
        binding.textView7.text = "$cif2"
        when ((0..3).random()) {
            0 -> binding.textView5.text = "*"
            1 -> binding.textView5.text = "/"
            2 -> binding.textView5.text = "-"
            3 -> binding.textView5.text = "+"
        }
    }



    private fun AnswereProverka(){
        val answere = binding.answere.text.toString().toIntOrNull() ?: 0

        val cif1 = binding.textView6.text.toString().toInt()
        val cif2 = binding.textView7.text.toString().toInt()
        val znak = binding.textView5.text.toString()
        var result = 0
        when (znak) {
            "*" -> result = cif1 * cif2
            "/" -> result = cif1 / cif2
            "-" -> result = cif1 - cif2
            "+" -> result = cif1 + cif2
        }



        if (answere == result) {
            setColor(Color.GREEN)
            pravAnswers++
        } else {
            setColor(Color.RED)
            nepravAnswers++
        }
        obshiyAnswers += 1
        obnovaInterface()
        binding.button.isEnabled = true
    }
    override fun onSaveInstanceState(instanceState: Bundle) {
        super.onSaveInstanceState(instanceState)
        instanceState.putInt("correctAnswers", pravAnswers)
        instanceState.putInt("incorrectAnswers", nepravAnswers)
        instanceState.putInt("totalAnswers", obshiyAnswers)
        instanceState.putInt("color", color)
        instanceState.putInt("cif1", binding.textView6.text.toString().toInt())
        instanceState.putInt("cif2", binding.textView7.text.toString().toInt())
        instanceState.putString("qwe", binding.textView4.text.toString())
        instanceState.putString("znak", binding.textView5.text.toString())
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        pravAnswers = savedInstanceState.getInt("correctAnswers")
        nepravAnswers = savedInstanceState.getInt("incorrectAnswers")
        obshiyAnswers = savedInstanceState.getInt("totalAnswers")
        color = savedInstanceState.getInt("color")
        binding.textView6.text = savedInstanceState.getInt("cif1").toString()
        binding.textView7.text = savedInstanceState.getInt("cif2").toString()
        binding.textView4.text = savedInstanceState.getString("qwe").toString()
        binding.textView5.text = savedInstanceState.getString("znak").toString()
        obnovaInterface()
        setColor(color)
    }
    }

